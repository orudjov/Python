Do not try at home! Try with a safe sandbox if possible.
